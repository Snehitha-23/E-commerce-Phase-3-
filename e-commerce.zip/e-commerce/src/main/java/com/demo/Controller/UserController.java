package com.demo.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

import com.demo.model.User;
import com.demo.service.UserService;

@RestController
public class UserController {
@Autowired
public UserService service;
@PostMapping("user")
public User addUser(User user) {
	return service.addUser(user);
}

	@GetMapping("/user/{Id}")
	public User getUserById(int ID) {
	
		return service.getUserById(ID);
	}

	@GetMapping("/user/emailId")
	public User getUserByEmailId(String emailId) {
		
		return service.getUserByEmailId(emailId);
	}

	@PutMapping("/user")
	public void updateUser(User user) {
	service.updateUser(user);
		
	}

	@GetMapping("/users")
	public List<User> getAllUsers() {
	
		return service.getAllUsers();
	}
	
	
	
	
	
	
	
	
}
