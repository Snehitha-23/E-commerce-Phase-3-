package com.demo.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

import com.demo.model.PurchaseItems;
import com.demo.service.PurchaseItemsService;
@RestController
public class PurchaseItemsController {
	@Autowired
	private PurchaseItemsService service;
	@GetMapping("/item/{Id}")
public PurchaseItems getItemById(int ID) {
		
		return service.getItemById(ID);
	}

	@GetMapping("/purchasedItems/{Id}")
	public List<PurchaseItems> findAllItemsByPurchaseId(int purchaseId) {
		return service.findAllItemsByPurchaseId(purchaseId);
	}

	@PutMapping("/updateitem")
	public void updateItem(PurchaseItems item) {
		service.updateItem(item);
		
	}

	@DeleteMapping("/deleteitem")
	public void deleteItem(int ID) {
	service.deleteItem(ID);
		
	}

	@DeleteMapping("/deleteItems/{Id}")
	public void deleteAllItemsForPurchaseId(int purchaseId) {
	service.deleteAllItemsForPurchaseId(purchaseId);
	
	}
	@PostMapping("/addItem")
		public PurchaseItems addItem(PurchaseItems item)
		{
		return service.addItem(item);
		}
	}
	
	

