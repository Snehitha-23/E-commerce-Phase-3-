package com.demo.service;

import java.util.List;

import com.demo.model.Category;

public interface CategoryService {
public Category addCategory(Category category);
	public Category getCategoryById(int Id);
	public Category updateCategory(Category category);
	 public void deleteCategory(int Id);
	 public List<Category> getAllCategories();
}
