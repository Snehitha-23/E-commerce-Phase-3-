package com.demo.service;

public interface AdminService {


}
