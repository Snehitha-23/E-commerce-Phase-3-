package com.demo.service;

import java.util.List;

import com.demo.model.Product;

public interface ProductService {
public Product getProductById(int ID);
public Product addProduct(Product product);
public void updateProduct(Product product);
public void deleteProduct(Product product);
public List<Product>getAllProducts();
}
