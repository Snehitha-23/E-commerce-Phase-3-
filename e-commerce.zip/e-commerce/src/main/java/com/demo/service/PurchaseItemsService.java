package com.demo.service;

import java.util.List;

import com.demo.model.PurchaseItems;

public interface PurchaseItemsService {
public PurchaseItems getItemById(int ID);

public void updateItem(PurchaseItems item);
public void deleteItem(int ID);
public void deleteAllItemsForPurchaseId(int purchaseId);
 public List<PurchaseItems> findAllItemsByPurchaseId(int purchaseId);

public PurchaseItems addItem(PurchaseItems item);
	
	
	
	
}
