package com.demo.service;

import java.util.List;

import com.demo.model.User;

public interface UserService {

	public User authenticate(String ID,String pwd);
	public User getUserById(int ID);
	public User getUserByEmailId(String emailId);
	public void updateUser(User user);
	public List<User>getAllUsers();
	public User addUser(User user);
	
	
	
	
}
