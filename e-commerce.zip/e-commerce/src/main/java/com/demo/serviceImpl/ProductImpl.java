package com.demo.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.model.Product;
import com.demo.repository.ProductRepository;
import com.demo.service.ProductService;
@Service
public class ProductImpl implements ProductService{
@Autowired
private ProductRepository productDAO;
	@Override
	public Product getProductById(int ID) {
		return productDAO.findById(ID).get();
	}

	@Override
	public void updateProduct(Product product) {
	productDAO.save(product);
		
	}

	@Override
	public void deleteProduct(Product product) {
		productDAO.delete(product);
		
	}

	@Override
	public List<Product> getAllProducts() {
		return productDAO.findAll();
	}

	@Override
	public Product addProduct(Product product) {
	
		return productDAO.save(product);
	}

}
