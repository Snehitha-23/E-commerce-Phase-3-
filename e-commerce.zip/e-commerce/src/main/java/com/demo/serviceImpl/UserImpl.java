package com.demo.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.model.User;
import com.demo.repository.UserRepository;
import com.demo.service.UserService;
@Service
public class UserImpl implements UserService{

	@Autowired
	private UserRepository userDAO;
	
	@Override
	public User authenticate(String userId, String pwd) {
		
		return null;
	}

	@Override
	public User getUserById(int ID) {
	
		return userDAO.findById(ID).get();
	}

	@Override
	public User getUserByEmailId(String emailId) {
		
		return userDAO.findByEmailId(emailId);
	}

	@Override
	public void updateUser(User user) {
		userDAO.save(user);
		
	}

	@Override
	public List<User> getAllUsers() {
	
		return userDAO.findAll();
	}

	@Override
	public User addUser(User user) {
		// TODO Auto-generated method stub
		return userDAO.save(user);
	}

}
