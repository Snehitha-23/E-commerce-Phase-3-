package com.demo.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.model.Purchase;
import com.demo.repository.PurchaseRepository;
import com.demo.service.PurchaseService;
@Service
public class PurchaseImpl implements PurchaseService{
@Autowired
public PurchaseRepository dao;
	@Override
	public Purchase addPurchase(Purchase purchase) {
		// TODO Auto-generated method stub
		return dao.save(purchase);
	}

	@Override
	public Purchase getPurchaseById(long id) {
		// TODO Auto-generated method stub
		return  dao.findById(id).get();
	}

	@Override
	public List<Purchase> getAllItems() {
		// TODO Auto-generated method stub
		return dao.findAll();
	}

	@Override
	public Purchase updatePurchase(Purchase purchase) {
		// TODO Auto-generated method stub
		return dao.save(purchase);
	}

	@Override
	public void deletePurchase(long id) {
		// TODO Auto-generated method stub
		dao.deleteById(id);
	}

	
	
	
}
