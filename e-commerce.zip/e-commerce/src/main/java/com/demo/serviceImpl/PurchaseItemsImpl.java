package com.demo.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.model.PurchaseItems;
import com.demo.repository.PurchaseItemsRepository;
import com.demo.service.PurchaseItemsService;
@Service
public class PurchaseItemsImpl implements PurchaseItemsService{
@Autowired
private PurchaseItemsRepository  purchaseDAO;
	@Override
	public PurchaseItems getItemById(int ID) {
		
		return purchaseDAO.findById(ID).get();
	}

	@Override
	public List<PurchaseItems> findAllItemsByPurchaseId(int purchaseId) {
		return purchaseDAO.findAllPurchaseItemsByPurchaseId(purchaseId);
	}

	@Override
	public void updateItem(PurchaseItems item) {
		purchaseDAO.save(item);
		
	}

	@Override
	public void deleteItem(int ID) {
		purchaseDAO.deleteById(ID);
		
	}

	@Override
	public void deleteAllItemsForPurchaseId(int purchaseId) {
	purchaseDAO.deleteById(purchaseId);
		
	}

	@Override
	public PurchaseItems addItem(PurchaseItems item) {
	 return purchaseDAO.save(item);
		
	}

}
