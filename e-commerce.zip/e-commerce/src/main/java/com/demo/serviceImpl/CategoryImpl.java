package com.demo.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.model.Category;
import com.demo.repository.CategoryRepository;
import com.demo.service.CategoryService;
@Service
public class CategoryImpl implements CategoryService {
@Autowired
private CategoryRepository dao;
	@Override
	public Category getCategoryById(int Id) {
		return dao.findById(Id).get();
	}

	@Override
	public Category updateCategory(Category category) {
	return dao.save(category);
		
	}

	@Override
	public void deleteCategory(int id) {
		dao.deleteById(id); 
		
	}

	@Override
	public List<Category> getAllCategories() {
		// TODO Auto-generated method stub
		return dao.findAll();
	}

	@Override
	public Category addCategory(Category category) {
		return dao.save(category);
	}

	

}
