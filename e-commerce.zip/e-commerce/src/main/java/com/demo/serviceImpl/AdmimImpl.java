package com.demo.serviceImpl;

public class AdmimImpl {

}
