package com.demo.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.ToString;  


@Entity
@Table  
@AllArgsConstructor
@ToString
public class PurchaseItems { 


	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID")
	private int ID;
	
	private int purchaseId;
	
	
	//@OneToMany
	//@Column(name = "product_id")
	//private  List<Product>productId=new ArrayList<>();

	@Column(name = "product_id")
	private  int productId;
	
	@Column(name = "user_id")
	private int userId;

	@Column(name = "rate")
	private BigDecimal rate;

	@Column(name = "qty")
	private int qty;

	@Column(name = "price")
	private BigDecimal price;

	
	public int getID() {return this.ID; }
	public int getPurchaseId() { return this.purchaseId;}
	public int getProductId() { return this.productId;}
	public int getUserId() { return this.userId;}
	public BigDecimal getRate() { return this.rate;}	
	public int getQty() { return this.qty;}	
	public BigDecimal getPrice() { return this.price;}
	
	public void setID(int id) { this.ID = id;}
	public void setPurchaseId(int value) { this.purchaseId = value;}
	public void setProductId(int value) { this.productId = value;}
	public void setUserId(int value) { this.userId = value;}
	public void setRate(BigDecimal value) { this.rate = value;}
	public void setQty(int value) { this.qty= value;}
	public void setPrice(BigDecimal value) { this.price= value;}
	
	

}
