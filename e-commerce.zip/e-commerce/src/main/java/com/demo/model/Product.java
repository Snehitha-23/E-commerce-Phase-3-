package com.demo.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.ToString;  


@Entity
@Table(name= "eproduct")  
@AllArgsConstructor
@ToString
public class Product { 


	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID")
	private int ID;
	
	@Column(name = "name")
	private String name;
	
	@Column(name = "price")
	private BigDecimal price;
	
	@Column(name = "date_added")
	private Date dateAdded;  
    
	@Column(name = "category_id")
	int categoryId;  
	
	@ManyToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY )

	@JoinTable(name = "products_Purchase",

	joinColumns = @JoinColumn(name="product_id"),

	inverseJoinColumns = @JoinColumn(name="purchaseitem_id"))

	List<Purchase> purchase = new ArrayList<>(); 

	public int getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}
	public int getID() {return this.ID; }  
	public String getName() { return this.name;} 
	public BigDecimal getPrice() { return this.price;} 
	
	public Date getDateAdded() { return this.dateAdded;}

	
	public void setID(int id) { this.ID = id;}
	public void setName(String value) { this.name = value;}
	public void setPrice(BigDecimal value) { this.price = value;}
	
	public void setDateAdded(Date date) { this.dateAdded = date;}
}
