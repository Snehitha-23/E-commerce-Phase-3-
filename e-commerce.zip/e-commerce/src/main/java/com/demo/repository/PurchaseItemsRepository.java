package com.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.demo.model.PurchaseItems;
@Repository
public interface PurchaseItemsRepository  extends JpaRepository<PurchaseItems,Integer>{
	@Query("SELECT u FROM PurchaseItems u WHERE u.purchaseId = purchaseId")
	List<PurchaseItems> findAllPurchaseItemsByPurchaseId(int purchaseId);
}
